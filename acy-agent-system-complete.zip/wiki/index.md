# acy Wiki Index
# LLM Knowledge Base for Agentic Security Research
# ROOT: ~/agents/acy/wiki/

---

## How to Use This Wiki

This wiki is the **persistent, compounding knowledge base** for the acy security research agent.
Every finding, technique, target, and session is documented here with structured metadata.

### Wiki Page Types

| Type | Purpose | Example |
|------|---------|---------|
| target | Per-target intelligence and surface mapping | [[target/api_target_com_3000]] |
| technique | Per-vulnerability-class deep knowledge | [[technique/sqli]] |
| session | Per-session log and findings | [[session/2026-06-25-session-001]] |
| chain | Attack chain documentation | [[chain/subdomain-takeover-to-ato]] |
| moc | Map of Content - index for a topic area | [[moc/injection-vulns]] |
| raw-ref | Reference to raw/ documents | [[raw/cve-2024-1234]] |

### YAML Frontmatter (required on every page)

```yaml
---
id: {uuid}
date: {ISO8601}
type: {target|technique|session|chain|moc|raw-ref}
status: {draft|active|completed|archived}
confidence: {1-5}
tags: [tag1, tag2]
links:
  - [[wiki/page-name]]
---
```

### Wiki-Link Syntax

Use `[[wiki/page-name]]` for bi-directional links between pages.
The agent automatically maintains backlink indexes.

---

## Target Pages

| Target | Status | Last Updated | Findings |
|--------|--------|--------------|----------|
| [Add targets here] | | | |

## Technique Pages

| Technique | Status | Findings Count | Last Updated |
|-----------|--------|----------------|--------------|
| [[technique/sqli]] | | | |
| [[technique/nosqli]] | | | |
| [[technique/xss]] | | | |
| [[technique/ssrf]] | | | |
| [[technique/idor]] | | | |
| [[technique/jwt]] | | | |
| [[technique/oauth]] | | | |
| [[technique/business-logic]] | | | |
| [[technique/race-condition]] | | | |
| [[technique/prototype-pollution]] | | | |

## Session Pages

| Session | Target | Findings | Status |
|---------|--------|----------|--------|
| [Add sessions here] | | | |

## Chain Pages

| Chain | Findings Chained | Impact | Status |
|-------|-----------------|--------|--------|
| [Add chains here] | | | |

## Maps of Content (MOCs)

- [[moc/injection-vulns]] - SQLi, NoSQLi, CMDi, SSTI, XXE, SSRF
- [[moc/auth-vulns]] - IDOR, JWT, OAuth, Session, Access Control
- [[moc/clientside-vulns]] - XSS, CSRF, CORS, Prototype Pollution
- [[moc/logic-vulns]] - Business Logic, Race Conditions, Mass Assignment
- [[moc/recon-intel]] - Reconnaissance, Subdomain Takeover, Info Disclosure

---

*acy Wiki Index - Updated automatically by agent*
