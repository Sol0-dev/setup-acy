---
id: {uuid}
date: {ISO8601}
type: finding
status: confirmed
confidence: 5
severity: {critical|high|medium|low}
cia: {C:H/I:H/A:H etc}
target: {target-slug}
vuln_class: {class}
surface: {endpoint}
links:
  - [[wiki/target/{slug}]]
  - [[wiki/technique/{class}]]
  - [[wiki/session/{session_id}]]
---

# {Impact-First Title}

## Summary
[One paragraph: what the bug is and why it matters]

## Impact
- Confidentiality: [C rating and explanation]
- Integrity: [I rating and explanation]
- Availability: [A rating and explanation]

## Steps to Reproduce
1. [step with exact request/response]
2. [step]
3. [step]

## Evidence
```
[request/response showing the bug]
```

## PoC Script
[link to {title}.sh]

## Chain Potential
[What other findings could this chain with?]

## Recommendations
[How to fix]
