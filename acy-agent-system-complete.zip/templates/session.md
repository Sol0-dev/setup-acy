---
id: {session_id}
date: {ISO8601}
type: session
target: {target-slug}
status: {active|completed}
links:
  - [[wiki/target/{slug}]]
---

# Session: {session_id}

## Target
{TARGET}

## Phase Progress
| Phase | Status | Notes |
|-------|--------|-------|
| 0 - Recon | | |
| 1 - App Understanding | | |
| 2 - Surface Classification | | |
| 3-41 - Vuln Testing | | |
| 42 - Chain Engine | | |
| 43 - Subdomain Expansion | | |
| 44 - Verification | | |

## Findings
[Links to confirmed findings]

## Next Actions
[What to do next session]
