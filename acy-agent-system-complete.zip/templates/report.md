# Security Assessment Report
# Target: {TARGET}
# Date: {date}
# Prepared by: acy Agent

## Executive Summary
[2-3 sentences: what was found, how bad it is, what could happen]

## Findings Summary
| Severity | Count | Classes |
|----------|-------|---------|
| Critical | {n} | [list] |
| High | {n} | [list] |
| Medium | {n} | [list] |
| Low | {n} | [list] |

## Detailed Findings
[Link to each finding note]

## Recommendations
[Specific, actionable fixes]

## Appendix
[PoC scripts, evidence, chain diagrams]
