---
id: {uuid}
date: {ISO8601}
type: target-moc
status: active
target: {target-slug}
links:
  - [[wiki/index]]
---

# Target MOC: {TARGET}

## Basic Info
- URL: {TARGET}
- Tech Stack: [detected from recon]
- Auth Type: [JWT/Session/OAuth/API Key]
- Database: [MySQL/Postgres/MongoDB/...]

## Surfaces
| Surface | Type | Vuln Classes | Status |
|---------|------|-------------|--------|
| | | | |

## Findings
| Finding | Severity | Class | Status |
|---------|----------|-------|--------|
| | | | |

## Intelligence
- [[wiki/recon/{slug}]] - Reconnaissance results
- [[wiki/js-intel/{slug}]] - JavaScript intelligence
- [[wiki/app-understanding/{slug}]] - Application mapping

## Chain Candidates
[Potential chains based on findings]
