# acy Agentic Security Research - Claude Code Bridge

## System Root

`~/agents/acy/`

## Main Orchestrator

`~/agents/acy/CLAUDE.md` - Read this first for full system documentation

## Skill Modules

Skills are loaded from `~/agents/acy/skills/SKILL-*.md`:
- SKILL-RECON.md - Reconnaissance
- SKILL-INTEL.md - JS Intelligence
- SKILL-INJECTION.md - Injection vulnerabilities
- SKILL-AUTH.md - Authentication & Authorization
- SKILL-CLIENTSIDE.md - Client-side vulnerabilities
- SKILL-LOGIC.md - Business Logic
- SKILL-CHAIN.md - Attack Chaining
- SKILL-REPORT.md - Reporting

## Quick Start

1. Set TARGET in `~/agents/acy/essentials/TARGET.env`
2. Say "let's hunt" to start the agent
3. The agent reads state, loads skills, and executes phases automatically
