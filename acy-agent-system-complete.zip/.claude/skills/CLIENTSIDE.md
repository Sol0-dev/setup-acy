# Client-Side Vulnerabilities - XSS, CSRF, CORS, prototype pollution, DOM clobbering, WebSocket

## Overview

This is an acy (Agentic Cyber Yield) skill module for automated security research.
Part of the modular SKILL.md system.

## Full Documentation

See the complete skill file at: `~/agents/acy/skills/SKILL-CLIENTSIDE.md`

## Quick Reference

- Phase Coverage: See full skill file
- Vulnerability Classes: See full skill file
- Purpose: See full skill file

## Usage

Load this skill when the agent is in the corresponding phase:
- Load SKILL-RECON.md during Phase 0 (Reconnaissance)
- Load SKILL-INTEL.md during Phases 0-1 (JS Intelligence & App Understanding)
- Load SKILL-INJECTION.md during Phases 3-4, 7-10, 18-19, 22-24, 31-32, 38, 40-41
- Load SKILL-AUTH.md during Phases 11-15, 34
- Load SKILL-CLIENTSIDE.md during Phases 5-6, 17, 20-21, 25, 29-30, 33
- Load SKILL-LOGIC.md during Phases 26-28, 35
- Load SKILL-CHAIN.md during Phase 42 (after every confirmed finding)
- Load SKILL-REPORT.md during Phase 44 (Verification & Hardening)

## System Root

All operations use `~/agents/acy/` as root.
